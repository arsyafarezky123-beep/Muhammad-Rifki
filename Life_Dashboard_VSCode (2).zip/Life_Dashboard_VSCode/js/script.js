const $ = (id) => document.getElementById(id);

// Greeting and live clock
function updateClock() {
  const now = new Date();
  $("clock").textContent = now.toLocaleTimeString("id-ID", { hour12: false });
  $("date").textContent = now.toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });
  const hour = now.getHours();
  $("greeting").textContent = hour < 11 ? "Good Morning!" : hour < 15 ? "Good Afternoon!" : hour < 18 ? "Good Evening!" : "Good Night!";
}
updateClock();
setInterval(updateClock, 1000);

// Personal name
const savedName = localStorage.getItem("lifeDashboardName") || "";
$("nameInput").value = savedName;
$("nameInput").addEventListener("input", () => localStorage.setItem("lifeDashboardName", $("nameInput").value.trim()));

// Theme toggle
if (localStorage.getItem("lifeDashboardTheme") === "dark") document.body.classList.add("dark");
function updateThemeIcon() { $("themeToggle").textContent = document.body.classList.contains("dark") ? "☀" : "☾"; }
updateThemeIcon();
$("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("lifeDashboardTheme", document.body.classList.contains("dark") ? "dark" : "light");
  updateThemeIcon();
});

// Focus timer
let duration = 25 * 60;
let remaining = duration;
let timerInterval = null;
function renderTimer() {
  const mins = Math.floor(remaining / 60);
  const secs = remaining % 60;
  $("timer").textContent = `${String(mins).padStart(2,"0")}:${String(secs).padStart(2,"0")}`;
  $("progressBar").style.width = `${((duration - remaining) / duration) * 100}%`;
}
$("startBtn").addEventListener("click", () => {
  if (timerInterval) return;
  timerInterval = setInterval(() => {
    if (remaining > 0) { remaining--; renderTimer(); }
    else { clearInterval(timerInterval); timerInterval = null; alert("Session complete! Great work."); }
  }, 1000);
});
$("stopBtn").addEventListener("click", () => { clearInterval(timerInterval); timerInterval = null; });
$("resetBtn").addEventListener("click", () => {
  clearInterval(timerInterval); timerInterval = null; remaining = duration; renderTimer();
});
$("setDurationBtn").addEventListener("click", () => {
  const value = Number($("durationInput").value);
  if (!Number.isInteger(value) || value < 1 || value > 120) return alert("Choose a duration between 1 and 120 minutes.");
  clearInterval(timerInterval); timerInterval = null;
  duration = value * 60; remaining = duration; renderTimer();
});
renderTimer();

// To-do list with local storage, edit, complete, delete, duplicate prevention and sorting
let tasks = JSON.parse(localStorage.getItem("lifeDashboardTasks") || "[]");
function saveTasks() { localStorage.setItem("lifeDashboardTasks", JSON.stringify(tasks)); }
function renderTasks() {
  const list = $("taskList");
  list.innerHTML = "";
  const mode = $("taskSort").value;
  const visible = [...tasks];
  if (mode === "newest") visible.reverse();
  if (mode === "active") visible.sort((a,b) => Number(a.done) - Number(b.done));
  visible.forEach(task => {
    const li = document.createElement("li");
    li.className = `task-item${task.done ? " done" : ""}`;
    const check = document.createElement("input");
    check.type = "checkbox"; check.checked = task.done; check.setAttribute("aria-label", "Tandai selesai");
    check.addEventListener("change", () => { task.done = check.checked; saveTasks(); renderTasks(); });
    const title = document.createElement("span"); title.className = "task-title"; title.textContent = task.text;
    const actions = document.createElement("div"); actions.className = "task-actions";
    const edit = document.createElement("button"); edit.className = "small-btn"; edit.textContent = "Edit";
    edit.addEventListener("click", () => {
      const changed = prompt("Edit task:", task.text);
      if (changed === null) return;
      const value = changed.trim();
      if (!value) return;
      if (tasks.some(t => t !== task && t.text.toLowerCase() === value.toLowerCase())) return alert("Task already exists.");
      task.text = value; saveTasks(); renderTasks();
    });
    const del = document.createElement("button"); del.className = "small-btn delete"; del.textContent = "Delete";
    del.addEventListener("click", () => { tasks = tasks.filter(t => t.id !== task.id); saveTasks(); renderTasks(); });
    actions.append(edit, del); li.append(check, title, actions); list.append(li);
  });
  $("taskCount").textContent = `${tasks.filter(t => !t.done).length} active · ${tasks.length} total`;
  $("emptyTasks").hidden = tasks.length > 0;
}
$("taskForm").addEventListener("submit", e => {
  e.preventDefault();
  const value = $("taskInput").value.trim();
  if (!value) return;
  if (tasks.some(t => t.text.toLowerCase() === value.toLowerCase())) return alert("That task is already on your list.");
  tasks.push({ id: Date.now(), text: value, done: false });
  $("taskInput").value = ""; saveTasks(); renderTasks();
});
$("taskSort").addEventListener("change", renderTasks);
renderTasks();

// Quick links saved in local storage
let links = JSON.parse(localStorage.getItem("lifeDashboardLinks") || "null");
if (!links) {
  links = [
    { id: 1, name: "Google", url: "https://google.com" },
    { id: 2, name: "Gmail", url: "https://mail.google.com" },
    { id: 3, name: "Calendar", url: "https://calendar.google.com" }
  ];
}
function saveLinks() { localStorage.setItem("lifeDashboardLinks", JSON.stringify(links)); }
function renderLinks() {
  const container = $("quickLinks"); container.innerHTML = "";
  links.forEach(link => {
    const a = document.createElement("a"); a.className = "link-chip"; a.href = link.url;
    a.target = "_blank"; a.rel = "noopener noreferrer"; a.title = link.url;
    const label = document.createElement("span"); label.textContent = link.name;
    const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×";
    remove.setAttribute("aria-label", `Hapus ${link.name}`);
    remove.addEventListener("click", e => {
      e.preventDefault(); e.stopPropagation();
      links = links.filter(item => item.id !== link.id); saveLinks(); renderLinks();
    });
    a.append(label, remove); container.append(a);
  });
}
$("linkForm").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("linkName").value.trim();
  let url = $("linkUrl").value.trim();
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  try { new URL(url); } catch { return alert("Please enter a valid URL."); }
  if (links.some(link => link.name.toLowerCase() === name.toLowerCase())) return alert("A link with that name already exists.");
  links.push({ id: Date.now(), name, url });
  $("linkName").value = ""; $("linkUrl").value = ""; saveLinks(); renderLinks();
});
saveLinks(); renderLinks();