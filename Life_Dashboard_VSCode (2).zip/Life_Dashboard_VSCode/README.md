# Life Dashboard

Project website To-Do List Life Dashboard.

## Cara membuka di Visual Studio Code
1. Extract file ZIP.
2. Buka Visual Studio Code.
3. Pilih **File > Open Folder**.
4. Pilih folder `life_dashboard`.
5. Install extension **Live Server** jika belum tersedia.
6. Klik kanan `index.html`, lalu pilih **Open with Live Server**.

## Struktur folder
```text
life_dashboard/
├── .vscode/
│   └── extensions.json
├── css/
│   └── style.css
├── js/
│   └── script.js
├── index.html
└── README.md
```

Website menggunakan HTML, CSS, JavaScript murni, dan Local Storage.
